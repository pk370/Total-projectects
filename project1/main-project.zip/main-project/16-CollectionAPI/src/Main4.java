import java.util.Set;
import java.util.TreeSet;

import pack1.Employee;
import pack1.EmployeeSalaryDescComparator;

public class Main4 {
     public static void main(String[] args) {
		 //
    	 
    	 EmployeeSalaryDescComparator employeeSalaryDescComparator=new EmployeeSalaryDescComparator();
    	 Set<Employee> set=new TreeSet<>();
	}
}
