package pack5;

public interface Acceptor<T> {
	
	void accept(T t);
}
