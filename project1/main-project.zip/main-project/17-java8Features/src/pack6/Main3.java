package pack6;

public class Main3 {
    public static void main(String[] args) {
		Square sq=new Square(10);
		
	}
}
