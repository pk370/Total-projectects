package pack6;

public class Main4 {
	void execute(Acceptor<String>a) {
		String s="ram";
		a.accept(s);
	}
	  public static void main(String[] args) {
//		  execute(e->{
//			  syso
//		  });
	}

}
