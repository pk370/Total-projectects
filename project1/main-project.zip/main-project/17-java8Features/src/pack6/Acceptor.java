package pack6;

public interface Acceptor<T> {
	
	void accept(T t);
}
