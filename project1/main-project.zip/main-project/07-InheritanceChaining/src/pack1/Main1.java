package pack1;

public class Main1 {
   public static void main(String[] args) {
	 B obj=new B(10,20);
}
   
}
