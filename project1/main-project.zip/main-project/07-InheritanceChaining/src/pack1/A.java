package pack1;

public class A {
    A(){
    	System.out.println("A-cons");
    }
    A(int i){
    	System.out.println("A-cons-i");
    }
}
