package pack1;

 class X {

}
