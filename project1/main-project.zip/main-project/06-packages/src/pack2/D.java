package pack2;

import pack1.A;

public class D {
    public void test3() {
    	A obj=new A();
//    	System.out.println(obj.v1); error
//    	System.out.println(obj.v2); error
//    	System.out.println(obj.v3); error
//    	System.out.println(obj.v4); error
    }
}
