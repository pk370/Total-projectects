
public class Square {
     private int size;
     public void setSize(int size) {
		this.size = size;
	}
     public int getSize() {
		return size;
	}
     int computeArea() {
    	 return size*size;
     }
}
