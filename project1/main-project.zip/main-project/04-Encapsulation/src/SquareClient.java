
public class SquareClient {
    public static void main(String[] args) {
		Square square=new Square();
		square.setSize(45);
		System.out.println(square.getSize());
		
		Square square2=new Square();
		square.setSize(6);
		System.out.println(square.getSize());
	}
}
