package pack1;

public class A {
    public int sum(int a,int b) {
    	return a+b;
    }
    public int sum(int a,int b,int c) {
    	return a+b+c;
    }
    public double sum(float a,double b) {
    	return a+b;
    }
}

