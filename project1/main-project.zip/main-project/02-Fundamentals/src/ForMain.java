
public class ForMain {
  public static void main(String[] args) {
	for(int i=1000;i<=1500;i=i+2) {
		System.out.println(i);
	}
}
}
