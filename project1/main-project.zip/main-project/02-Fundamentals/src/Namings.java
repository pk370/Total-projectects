
public class Namings {
    public static void main(String[] args) {
		int age;
		int age10;
//		int 10age; illegal
		int age_10;
		int age$10;
		
		int _age;
		int $age;
	}
    
    public void calculate_10() {
    	
    }
}
