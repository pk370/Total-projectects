
public class IfElseIfElseMain {
   public static void main(String[] args) {
	   int score=83;
	   
	    if(score>=90) {
	    	System.out.println("A");
	    }
	    else if(score>=60) {
	    	System.out.println("B");
	    }
	    else if(score>=40) {
	    	System.out.println("C");
	    }
	    else {
	    	System.out.println("D");
	    }
      
}
}
