
public class NamingConvention {
    int ageOfEmployee;
    
    public void calculateSum() {
    	
    }
    public void printFactorial() {
    	
    }
}
