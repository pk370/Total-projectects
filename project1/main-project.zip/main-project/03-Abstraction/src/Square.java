
public class Square {
   int size;
   int computeArea() {
	   return size*size;
   }
}
