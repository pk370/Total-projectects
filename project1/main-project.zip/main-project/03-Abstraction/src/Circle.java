
public class Circle {
   int radius;
   double getArea() {
	   return 3.14*radius*radius;
   }
}
