
public class CirclePrograme {
   public static void main(String[] args) {
     
	   Circle c1;
	   c1=new Circle();
	   c1.radius=4;
	   System.out.println(c1.radius);
	   System.out.println(c1.getArea());
	   
	   Circle c2;
	   c2=new Circle();
	   c2.radius=5;
	   System.out.println(c2.radius);
	   System.out.println(c2.getArea());
	   
	   Circle c3;
	   c3=new Circle();
	   c3.radius=8;
	   System.out.println(c3.radius);
	   System.out.println(c3.getArea());
	   
	   Circle c4;
	   c4=new Circle();
	   c4.radius=12;
	   System.out.println(c4.radius);
	   System.out.println(c4.getArea());
  }
}
