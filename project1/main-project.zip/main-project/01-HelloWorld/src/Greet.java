
public class Greet {
     public static void main(String[] args) {
		System.out.println("hello how are you?");
	}
}
