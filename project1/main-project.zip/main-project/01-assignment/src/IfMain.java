
public class IfMain {
	public static void main(String[] args) {
		int age=40;
		if(age>=18) {
			System.out.println("ELIGIBLE");
		}
	}

}
