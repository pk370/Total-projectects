package pack2;

import pack1.Employee;

public class Main9 {
	public static void main(String[] args) {
		Employee employee1=new Employee(101,"john",4000);
	    Employee employee2=new Employee(102,"sharuk",3000);
	    
	    System.out.println(employee1.equals(employee2));
	}
    
   
}
