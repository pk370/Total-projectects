package pack2;

import pack1.Employee;

public class Main3 {
    public static void main(String[] args) {
		Employee employee=new Employee(3,"yash",34);
		System.out.println(employee);
	}
}
