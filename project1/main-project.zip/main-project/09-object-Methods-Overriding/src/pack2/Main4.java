package pack2;
import pack1.Student;
public class Main4 {
    public static void main(String[] args) {
		Student student=new Student(101,"raju",49,56,86);
		System.out.println(student.toString());
	}
}
