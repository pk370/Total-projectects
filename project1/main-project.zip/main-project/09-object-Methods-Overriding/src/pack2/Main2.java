package pack2;

import pack1.Square;

public class Main2 {
     public static void main(String[] args) {
		 Square s=new Square(10);
		 System.out.println(s.toString());
		 System.out.println(s);
	}
}
